import React, { Component } from 'react';
import Person from './Person/Person'
import './App.css';

class App extends Component {
  state = {
    persons: [
      {id: 1, name:'Arun',age:'25'},
      {id: 2,name:'Partha',age:'27'},
      {id: 3,name:'Abhishek',age:'30'},
      {id: 4,name:'Bibek',age:'25'}
    ],
    showPersons: false
  };

  changeNameHandler = (event, personId) => {
    const personIndex = this.state.persons.findIndex(p => {
      return p.id === personId;
    });
    const person = {
      ...this.state.persons[personIndex]
    };
    // const person = Object.assign({}, this.state.persons[personIndex]);
    person.name = event.target.value;
    const persons = [...this.state.persons];
    persons[personIndex] = person;

    this.setState({persons: persons});
  }
  togglePersonsHandler = () =>{
    this.setState({showPersons: !this.state.showPersons});
  }
  deletePersonHandler = (personIndex) => {
    // const persons = this.state.persons;
    // const persons = this.state.persons.slice();
    const persons = [...this.state.persons];
    persons.splice(personIndex, 1);
    this.setState({persons: persons});
  }
  render() {
    const style = {
      backgroundColor: 'white',
      font: 'inherit',
      border: '1px solid blue',
      padding: '8px',
      cursor: 'pointer'
    };
    let persons = null;
    if(this.state.showPersons){
      persons = (
        <div>
          {this.state.persons.map((person, index) => {
            return <Person 
              key={person.id}
              click={this.deletePersonHandler.bind(this, index)}
              name={person.name}
              age={person.age}
              changed={(event)=>this.changeNameHandler(event, person.id)}/>
          })}
          {/* <Person name={this.state.persons[0].name} age={this.state.persons[0].age} click={this.switchNameHandler.bind(this, 'Arunoday!!')} changed={this.changeNameHandler}/>
          <Person name={this.state.persons[1].name} age={this.state.persons[1].age}/>
          <Person name={this.state.persons[2].name} age={this.state.persons[2].age}>My Hobbies are Racing</Person>
          <Person name={this.state.persons[3].name} age={this.state.persons[3].age}/> */}
        </div>
      );
    }
    return (
      <div className="App">
        <h1>Hi, React App</h1>
        <button style={style}
          onClick={this.togglePersonsHandler}>Toggle Persons</button>
        {persons}
      </div>
    );
    // React.createElement('div', null, 'h1', 'Hi, React App');
    // return React.createElement('div', {className:'App'}, React.createElement('h1', null, 'Hi, React App'));
  }
}

export default App;